package net.sourceforge.pmd.ast;

public class MultiLineComment extends Comment {

    public MultiLineComment(Token t) {
        super(t);
    }

}
