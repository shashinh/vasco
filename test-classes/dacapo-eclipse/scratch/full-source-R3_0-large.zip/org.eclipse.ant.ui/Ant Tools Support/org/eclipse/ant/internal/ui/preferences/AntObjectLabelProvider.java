/*******************************************************************************
 * Copyright (c) 2000, 2003 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 * 
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.eclipse.ant.internal.ui.preferences;

import java.text.MessageFormat;

import org.eclipse.ant.core.Property;
import org.eclipse.ant.core.Task;
import org.eclipse.ant.core.Type;
import org.eclipse.ant.internal.core.AntObject;
import org.eclipse.ant.internal.ui.model.AntUIImages;
import org.eclipse.ant.internal.ui.model.IAntUIConstants;
import org.eclipse.jface.viewers.IColorProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.ide.IDE;


/**
 * Label provider for type elements
 */
public class AntObjectLabelProvider extends LabelProvider implements ITableLabelProvider, IColorProvider {

	/* (non-Javadoc)
	 * Method declared on IBaseLabelProvider.
	 */
	public void dispose() {
	}
	
	/* (non-Javadoc)
	 * Method declared on ITableLabelProvider.
	 */
	public Image getColumnImage(Object element, int columnIndex) {
		if (element instanceof Property) {
			return getPropertyImage();
		} else if (element instanceof Type){
			return getTypeImage();
		} else if (element instanceof Task) {
			return getTaskImage();
		}
		return PlatformUI.getWorkbench().getSharedImages().getImage(ISharedImages.IMG_OBJ_FILE);
	}
	
	/* (non-Javadoc)
	 * Method declared on ITableLabelProvider.
	 */
	public String getColumnText(Object element, int columnIndex) {
		if (element instanceof Property) {
			Property property= (Property) element;
			if (property.isDefault()) {
				return element.toString() + MessageFormat.format(AntPreferencesMessages.getString("AntObjectLabelProvider.10"), new String[]{property.getPluginLabel()}); //$NON-NLS-1$
			} 
		} else if (element instanceof AntObject) {	
			AntObject object = (AntObject) element;
			StringBuffer text= new StringBuffer(object.toString());
			text.append(" ("); //$NON-NLS-1$
			text.append(object.getLibraryEntry().getLabel());
			text.append(": "); //$NON-NLS-1$
			text.append(object.getClassName());
			text.append(')');
			if (object.isDefault()) {
				text.append(MessageFormat.format(AntPreferencesMessages.getString("AntObjectLabelProvider.10"), new String[]{object.getPluginLabel()})); //$NON-NLS-1$
			}
			return text.toString();
		}
		 
		return element.toString();	
	}
	
	public Image getTypeImage() {
		return AntUIImages.getImage(IAntUIConstants.IMG_ANT_TYPE);
	}
	
	public Image getTaskImage() {
		return PlatformUI.getWorkbench().getSharedImages().getImage(IDE.SharedImages.IMG_OBJS_TASK_TSK);
	}

	public static Image getPropertyImage() {
		return AntUIImages.getImage(IAntUIConstants.IMG_PROPERTY);
	}
	
	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IColorProvider#getForeground(java.lang.Object)
	 */
	public Color getForeground(Object element) {
		return null;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.viewers.IColorProvider#getBackground(java.lang.Object)
	 */
	public Color getBackground(Object element) {
		if (element instanceof AntObject) {
			if (((AntObject) element).isDefault()) {
				Display display= Display.getCurrent();
				return display.getSystemColor(SWT.COLOR_INFO_BACKGROUND);		
			}
		} else if (element instanceof Property) {
			if (((Property) element).isDefault()) {
				Display display= Display.getCurrent();
				return display.getSystemColor(SWT.COLOR_INFO_BACKGROUND);		
			}
		}
		return null;
	}
}