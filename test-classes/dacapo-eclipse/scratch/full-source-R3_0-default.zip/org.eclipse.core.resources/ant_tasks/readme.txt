December 4, 2002 - dj

Note: This folder contains jars which contribute Ant tasks
to the org.eclipse.core.ant plug-in.
