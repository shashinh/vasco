December 4, 2002 - dj

Note: This folder contains libraries which are to be used
to compile against but are not contributed as part of the
binary representation of this plug-in.

ant.jar - This is a copy of the ant.jar which is included as
part of the org.apache.ant plug-in version 1.5.1.

antsupport.jar - This is a copy of the antsupport.jar which is 
included as part of the org.eclipse.ant.core plug-in version 2.1
in the 2002-12-03 integration build.
